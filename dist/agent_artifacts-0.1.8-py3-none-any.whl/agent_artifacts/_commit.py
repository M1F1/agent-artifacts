"""Source commit the package was built from (DESIGN.md §15).

Generated at build time by ``scripts/inject_commit.py`` (WP-21). The ``"unknown"`` default
is used for editable/dev installs and is only consulted by ``check`` / ``upgrade`` (WP-16/17).
"""

COMMIT = "5ca5cf9d898de4c411f5b79aa0dc35f53d8403e5"
