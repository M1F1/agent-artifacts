"""Source commit the package was built from (DESIGN.md §15).

Generated at build time by ``scripts/inject_commit.py`` (WP-21). The ``"unknown"`` default
is used for editable/dev installs and is only consulted by ``check`` / ``upgrade`` (WP-16/17).
"""

COMMIT = "c6c322057a7ce9502c7ed6e9339e7520ef4b1091"
