"""install command (WP-12). Gather configs -> plan_install -> execute/render -> manifest upsert.

Orchestration only (imperative shell, DESIGN.md §14). The decision logic lives in the pure
core: source resolution (WP-11), target/profile resolution + manifest glue (`_common`), and
`planners.plan_install` (WP-5). This module's single job is to assemble the inputs those
pieces need, thread `--dry-run`/`--json`/`--force`, run the executor, and persist the manifest.

Flow (matches the WP-12 contract):

1. ``open_source`` -> ``Source``.
2. ``Source.catalog()`` -> ``Catalog``.
3. ``_common.resolve_artifacts`` + ``_common.resolve_profiles``.
4. Assemble the ``files`` mapping (targets, guideline bodies, descriptors, source labels,
   per-profile existing-guideline text for idempotent append-sentinel).
5. Build ``profiles_map`` and ``configs`` (per-profile harness config for collision detection).
6. ``planners.plan_install`` -> ``Plan``.
7. ``_common.split_manifest`` + ``_common.rebase_plan`` (project-relative -> absolute).
8. ``--dry-run``: print the rendered/JSON plan and return without touching disk.
9. ``executor.execute`` the rebased plan.
10. Merge the manifest entries into the on-disk manifest (real `WriteFile` hashes from the
    pure plan; `CopyTree` payload hashes are left empty by the core — see DESIGN.md §12).
11. Print a human summary or JSON; return ``OK``.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from typing import Dict, List, Mapping, Optional, Tuple

from .. import executor, manifest, planners
from ..io import fs
from ..model import Artifact, Profile, Request
from ..source import Source, open_source
from . import _common


def _err(message: str) -> None:
    """Emit a single diagnostic line to stderr (commands are quiet on the happy path)."""
    print(message, file=sys.stderr)


def _read_guideline_existing(
    project: str, profiles: Tuple[Tuple[str, Profile], ...]
) -> Dict[str, str]:
    """Read each profile's append-sentinel destination file (if present) keyed for `files`.

    Returns ``{f"existing:{profile}:": <dest-relative-path>}`` markers' content — but keyed
    per artifact below. Here we only return the per-profile destination *file text* so the
    caller can attach it under ``existing:{profile}:{artifact}`` for every guideline that
    targets that profile. Missing files map to no entry (planner treats absent as empty).
    """
    out: Dict[str, str] = {}
    for pname, prof in profiles:
        target = prof.guidelines
        if target.mode != "append-sentinel":
            continue
        dest = os.path.normpath(os.path.join(project, target.dest))
        if fs.exists(dest):
            try:
                out[pname] = fs.read_text(dest)
            except OSError:  # pragma: no cover - defensive
                continue
    return out


def run(request: Request) -> int:
    """Install the requested artifacts into the selected profiles.

    Returns a process exit code (PLAN.md §7): ``OK`` (0) on success or dry-run; ``USAGE``
    (2) for a bad selection (unknown name/bundle/profile or no profile); ``NETWORK`` (3)
    for a remote-source failure; ``CONFLICT`` (4) for a merge collision needing ``--force``;
    ``CORRUPT_MANIFEST`` (5) for an unreadable manifest; ``ERROR`` (1) otherwise.
    """
    # 1. Resolve the source (local dir or remote snapshot).
    src_res = open_source(request)
    if isinstance(src_res, _common.Err):
        _err(src_res.reason)
        return _common.exit_code(src_res)
    src: Source = src_res.value

    # 2. Build the catalog from the source.
    cat_res = src.catalog()
    if isinstance(cat_res, _common.Err):
        _err(cat_res.reason)
        return _common.exit_code(cat_res)
    catalog = cat_res.value

    # 3. Resolve the requested artifacts and profiles.
    arts_res = _common.resolve_artifacts(request, catalog)
    if isinstance(arts_res, _common.Err):
        _err(arts_res.reason)
        return _common.USAGE
    profs_res = _common.resolve_profiles(request)
    if isinstance(profs_res, _common.Err):
        _err(profs_res.reason)
        return _common.USAGE

    arts: Tuple[Artifact, ...] = arts_res.value
    profs: Tuple[Tuple[str, Profile], ...] = profs_res.value
    project = _common.project_root(request)

    # 4. Assemble the `files` mapping that plan_install consumes.
    installed_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    files: Dict[str, object] = {
        "__targets__": tuple((a, pname) for a in arts for (pname, _prof) in profs),
        "__installed_at__": installed_at,
    }
    existing_text = _read_guideline_existing(project, profs)

    for a in arts:
        files[f"source:{a.name}"] = src.label()
        if a.type == "guideline":
            files[f"guideline:{a.name}"] = src.read(a.root).decode("utf-8")
            # Attach the destination file's current text per profile so that the
            # append-sentinel block stays idempotent across re-installs.
            for pname, _prof in profs:
                if pname in existing_text:
                    files[f"existing:{pname}:{a.name}"] = existing_text[pname]
        elif a.type in ("mcp", "hook"):
            # mcp descriptor lives at a.root (e.g. "mcp/postgres.json"); a hook's lives at
            # a.root + "/hook.json" (e.g. "hooks/block-secrets/hook.json").
            rel = a.root if a.type == "mcp" else f"{a.root}/hook.json"
            files[f"descriptor:{a.name}"] = json.loads(src.read(rel).decode("utf-8"))

    # 5. Build profile map + per-profile harness configs (for merge collision detection).
    #
    # LIMITATION: collision detection in plan_mcp/plan_hook is per-profile against a SINGLE
    # already-loaded config dict. We load each profile's mcp merge file from the project if
    # it exists and pass it as that profile's config. This catches collisions against
    # *previously written* config but not collisions between two artifacts merged in the
    # same run targeting the same key (the executor's merge performer is last-writer-wins /
    # dedup-on-equal for those). Hooks merge into a different file (list mode); we use the
    # same single dict, which is sufficient for the built-in profiles where mcp and hook
    # merge files differ. Downstream commands needing exact pre-merge state should reload.
    profiles_map: Dict[str, Profile] = {pname: prof for (pname, prof) in profs}
    configs: Dict[str, Mapping] = {}
    for pname, prof in profs:
        cfg: Mapping = {}
        merge_file = os.path.normpath(os.path.join(project, prof.mcp.file))
        if fs.exists(merge_file):
            try:
                loaded = fs.read_json(merge_file)
                if isinstance(loaded, dict):
                    # Hand the planner the sub-mapping it collision-checks against
                    # (json_path under the merge file, e.g. "mcpServers").
                    node = loaded
                    for part in (prof.mcp.json_path.split(".") if prof.mcp.json_path else []):
                        nxt = node.get(part) if isinstance(node, dict) else None
                        node = nxt if isinstance(nxt, dict) else {}
                    cfg = node if isinstance(node, dict) else {}
            except (OSError, json.JSONDecodeError, ValueError):  # pragma: no cover
                cfg = {}
        configs[pname] = cfg

    # 6. Build the full plan (pure). Accumulates every target's failure.
    manifest_res = _common.load_manifest(request)
    if isinstance(manifest_res, _common.Err):
        _err(manifest_res.reason)
        return _common.exit_code(manifest_res)

    plan_res = planners.plan_install(
        request, catalog, files, profiles_map, manifest_res.value, configs
    )
    if isinstance(plan_res, _common.Err):
        _err(plan_res.reason)
        return _common.exit_code(plan_res)
    plan = plan_res.value

    # 7. Split off the manifest entries; rebase the executable actions onto real roots.
    file_actions, entries = _common.split_manifest(plan)
    rebased = _common.rebase_plan(
        file_actions, source_root=src.root, project_root=project
    )

    # 8. Dry-run: print the plan and return without touching disk.
    if request.dry_run:
        if request.json:
            print(executor.plan_to_json(rebased))
        else:
            print(executor.render_plan(rebased))
        return _common.OK

    # 9. Execute the rebased plan (the only disk-touching step).
    report = executor.execute(rebased)

    # 10. Persist the consumer manifest (the command owns this — rebase_plan passes the
    #     WriteManifest through untouched because the executor writes it relative to CWD).
    m = manifest_res.value
    for entry in entries:
        m = manifest.upsert(m, entry)
    _common.save_manifest(project, m)

    # 11. Report.
    if request.json:
        _common.print_json(
            {
                "installed": [
                    {"artifact": e.artifact, "type": e.type, "profile": e.profile}
                    for e in entries
                ],
                "performed": list(report.performed),
                "warnings": list(report.warnings),
                "manifest": _common.manifest_path(project),
            }
        )
    else:
        _print_summary(entries, report)
    return _common.OK


def _print_summary(entries, report) -> None:
    """Print a concise human-readable install summary."""
    n = len(entries)
    print(f"Installed {n} artifact{'s' if n != 1 else ''}:")
    for e in entries:
        print(f"  - {e.type:<9} {e.artifact} -> {e.profile}")
    for w in report.warnings:
        print(f"warning: {w}")
