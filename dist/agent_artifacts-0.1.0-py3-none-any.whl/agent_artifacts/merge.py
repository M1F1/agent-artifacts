"""Generic merge engine — pure (WP-3). Drives both MCP (`key`) and hooks (`list`), DESIGN.md §10."""

from __future__ import annotations

from typing import Mapping, Tuple

from .model import MergeSpec, Result

_TODO = "WP-3: not implemented"


def render(template, descriptor: Mapping) -> object:
    """Fill ``${field}`` placeholders in a profile's `entry_template` from a hook descriptor."""
    raise NotImplementedError(_TODO)


def identity_of(spec: MergeSpec, value) -> Tuple:
    """Stable identity tuple for dedup/removal (the `spec.identity` fields of `value`)."""
    raise NotImplementedError(_TODO)


def plan_merge(spec: MergeSpec, value, existing: Mapping, *, force: bool = False) -> Result:
    """Plan a single merge into already-loaded `existing` config -> Ok[MergeJson] | Err (collision)."""
    raise NotImplementedError(_TODO)
