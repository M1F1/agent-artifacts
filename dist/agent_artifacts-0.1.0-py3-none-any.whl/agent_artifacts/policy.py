"""Update policy — pure (WP-2). Implements the per-file decision table (DESIGN.md §9)."""

from __future__ import annotations

from typing import Literal, Optional, Tuple

_TODO = "WP-2: not implemented"

Decision = Literal["create", "noop", "overwrite", "keep-drift", "conflict"]


def classify(disk: Optional[str], base: Optional[str], new: Optional[str]) -> Decision:
    """Classify a file given on-disk hash, installed (base) hash, and incoming (new) hash."""
    raise NotImplementedError(_TODO)


def decision_action(decision: Decision, path: str, content: bytes, *, force: bool = False) -> Tuple:
    """Turn a `Decision` into a tuple of `Action`s (conflict -> WriteFile(.agent-artifacts-new)+Warn)."""
    raise NotImplementedError(_TODO)
