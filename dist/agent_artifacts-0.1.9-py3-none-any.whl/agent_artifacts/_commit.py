"""Source commit the package was built from (DESIGN.md §15).

Generated at build time by ``scripts/inject_commit.py`` (WP-21). The ``"unknown"`` default
is used for editable/dev installs and is only consulted by ``check`` / ``upgrade`` (WP-16/17).
"""

COMMIT = "605837cede1d4732f608c592d1111e5bb70828a6"
