"""Source commit the package was built from (docs/design/DESIGN.md §15).

Generated at build time by ``scripts/inject_commit.py`` (WP-21). The ``"unknown"`` default
is used for editable/dev installs and is only consulted by ``check`` / ``upgrade`` (WP-16/17).
"""

COMMIT = "2eb26c8891ef7e8923b454565a5d54c5a19eb72c"
