"""Source commit the package was built from (docs/design/DESIGN.md §15).

Generated at build time by ``scripts/inject_commit.py`` (WP-21). The ``"unknown"`` default
is used for editable/dev installs and is only consulted by ``check`` / ``upgrade`` (WP-16/17).
"""

COMMIT = "08f5a6d20d557a5a16dceb1b4d6fd891286c92ff"
